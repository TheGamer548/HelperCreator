# Commands

# 1. create_html_documentation_file("path_directory, file_name")
# 2. create_documentation_file("path_directory, file_name")
# 3. end
## Help for commands :
## this command is utility for HTML devlopper. This command will create a html file in your path directory and you will start coding code
## The last command but not a html documentation

# Features for this version

## We added all functions on # Commands

# Thank you for using HelperCreator